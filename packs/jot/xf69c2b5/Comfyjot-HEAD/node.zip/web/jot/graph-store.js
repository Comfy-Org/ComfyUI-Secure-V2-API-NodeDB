import { DATA_VERSION, GRAPH_DATA_KEY, TOOLS } from "./constants.js";

function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, number));
}

function normalizePoint(point) {
  if (!Array.isArray(point) || point.length < 2) {
    return null;
  }

  const x = Number(point[0]);
  const y = Number(point[1]);
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    return null;
  }

  return [x, y];
}

function normalizeStroke(stroke, index) {
  if (!stroke || typeof stroke !== "object") {
    return null;
  }

  const tool = stroke.tool === TOOLS.ERASER ? TOOLS.ERASER : TOOLS.BRUSH;
  const points = Array.isArray(stroke.points)
    ? stroke.points.map(normalizePoint).filter(Boolean)
    : [];

  if (!points.length) {
    return null;
  }

  return {
    id: typeof stroke.id === "string" && stroke.id ? stroke.id : `stroke-${index}`,
    tool,
    color: typeof stroke.color === "string" && stroke.color ? stroke.color : "#ffb347",
    size: clampNumber(stroke.size, 1, 256, 10),
    points,
  };
}

export function createEmptyDocument() {
  return {
    version: DATA_VERSION,
    strokes: [],
  };
}

export function normalizeDocument(data) {
  if (!data || typeof data !== "object") {
    return createEmptyDocument();
  }

  const strokes = Array.isArray(data.strokes)
    ? data.strokes.map((stroke, index) => normalizeStroke(stroke, index)).filter(Boolean)
    : [];

  return {
    version: DATA_VERSION,
    strokes,
  };
}

export function cloneDocument(documentData) {
  return {
    version: DATA_VERSION,
    strokes: documentData.strokes.map((stroke) => ({
      id: stroke.id,
      tool: stroke.tool,
      color: stroke.color,
      size: stroke.size,
      points: stroke.points.map((point) => [point[0], point[1]]),
    })),
  };
}

export function readDocumentFromGraph(graph) {
  return normalizeDocument(graph?.extra?.[GRAPH_DATA_KEY]);
}

function markGraphDirty(graph) {
  graph?.setDirtyCanvas?.(true, true);
}

export function writeDocumentToGraph(graph, documentData) {
  if (!graph) {
    return;
  }

  const normalized = normalizeDocument(documentData);
  const hasContent = normalized.strokes.length > 0;

  graph.beforeChange?.();
  try {
    graph.extra ||= {};
    if (hasContent) {
      graph.extra[GRAPH_DATA_KEY] = normalized;
    } else {
      delete graph.extra[GRAPH_DATA_KEY];
    }
  } finally {
    graph.afterChange?.();
    markGraphDirty(graph);
  }
}
